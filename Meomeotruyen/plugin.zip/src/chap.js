function execute(url) {

    let response = fetch(url);

    if (response.ok) {

        let doc = response.html();

        let content = doc.select("#mainChapterContent");

        // xóa quảng cáo / khóa chương
        content.select(".chapter-lock-box").remove();

        let html = content.html()
            .replace(/<br\s*\/?>/gi, "\n")
            .replace(/<\/p>/gi, "\n")
            .replace(/<p[^>]*>/gi, "")
            .replace(/<div[^>]*>/gi, "")
            .replace(/<\/div>/gi, "")
            .replace(/<[^>]+>/g, "")
            .replace(/&nbsp;/g, " ")
            .replace(/\n\s*\n\s*\n+/g, "\n\n")
            .replace(/[ \t]+\n/g, "\n")
            .replace(/\n /g, "\n")
            .trim();

        return Response.success(html);
    }

    return null;
}