function execute(url) {

    let response = fetch(url);

    if (!response.ok) return null;

    let doc = response.html();

    let list = [];
    
    doc.select(".entries .entry-card").forEach(e => {

        let a = e.select("h5.entry-title a").first();

        if (!a) return;

        let name = a.text().trim();
        let link = a.attr("href");

        let cover = e.select(".ct-media-container img").attr("src");

        let chapter = e.select(".recent-chapter-info .rc-name").text().trim();

        let description = chapter;

        list.push({
            name: name,
            link: link,
            cover: cover,
            description: description,
            host: link
        });
    });

    return Response.success(list);
}