function execute(url) {

    let response = fetch(url);

    if (response.ok) {

        let doc = response.html();

        let name = doc.select(".truyen-title")
            .text()
            .trim();

        let cover = doc.select(".truyen-cover img")
            .attr("src");

        let description = doc.select(
            ".truyen-entry-content"
        ).html()
            .replace(/<br\s*\/?>/gi, "\n")
            .replace(/<\/p>/gi, "\n")
            .replace(/<p[^>]*>/gi, "")
            .replace(/<[^>]+>/g, "")
            .replace(/&nbsp;/g, " ")
            .replace(/\n\s*\n\s*\n+/g, "\n\n")
            .trim();

        let status = "";

        doc.select(".truyen-meta-box div")
            .forEach(e => {

                let text = e.text().trim();

                if (text.indexOf("Trạng thái") > -1) {

                    status = e.select("b")
                        .text()
                        .trim();
                }
            });

        let views = "";
        let updated = "";

        doc.select(".truyen-meta-box div")
            .forEach(e => {

                let text = e.text().trim();

                if (text.indexOf("Lượt xem") > -1) {

                    views = e.select("b")
                        .text()
                        .trim();
                }

                if (text.indexOf("Cập nhật") > -1) {

                    updated = e.select("b")
                        .text()
                        .trim();
                }
            });

        let detail =
            "Trạng thái\n" + status + "<br>" +
            "Lượt xem\n" + views + "<br>" +
            "Cập nhật\n" + updated;

        let ongoing =
            status.indexOf("Hoàn") === -1 &&
            status.indexOf("Full") === -1;

        return Response.success({
            name: name,
            cover: cover,
            host: url,
            author: null,
            description: description,
            detail: detail,
            ongoing: ongoing
        });
    }

    return null;
}