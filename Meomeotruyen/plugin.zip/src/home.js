function execute() {

    return Response.success([
        {
            title: "Truyện mới cập nhật",
            input: "https://meomeotruyen.site/",
            script: "gen.js"
        }
    ]);
}