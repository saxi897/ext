function execute(url) {

    let response = fetch(url);

    if (response.ok) {

        let doc = response.html();

        let list = [];

        doc.select(".chapter-item a")
            .forEach(e => {

                list.push({
                    name: e.text().trim(),
                    url: e.attr("href")
                });
            });            
list.reverse();
        return Response.success(list);
    }

    return null;
}