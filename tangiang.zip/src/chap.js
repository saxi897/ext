load('crypto.js');
load('decode.js');

function execute(url) {
    let isVipChapter = url.includes("token") || url.includes("versionCode=349");
    let token = "";

    // --- Ưu tiên lấy token từ app input ---
    if (typeof JJWXC_TOKEN !== 'undefined' && JJWXC_TOKEN) {
        token = JJWXC_TOKEN;
    }

    // --- Làm sạch token (xóa khoảng trắng, xuống dòng, tab, \r\n, vv) ---
    if (token && typeof token === "string") {
        token = token.trim().replace(/\s+/g, "");
    }

    // --- Nếu là VIP chapter mà URL chưa có token, thêm token vào ---
    if (isVipChapter) {
        if (!url.includes("token=")) {
            if (token && token.length > 10) {
                if (url.includes("?")) {
                    url += "&token=" + encodeURIComponent(token);
                } else {
                    url += "?token=" + encodeURIComponent(token);
                }
            } else {
                let html1 = `Token không hợp lệ hoặc chưa nhập.<br/>
                             Vui lòng nhập token vào phần "Mã bổ sung" hoặc "Cài đặt" với cú pháp:<br/>
                             <code>var JJWXC_TOKEN = "token_của_bạn";</code>`;
                return Response.success(html1);
            }
        }

        let response1 = fetch(url);
        if (!response1.ok) {
            return Response.success("Không thể kết nối đến server. Vui lòng thử lại.");
        }

        try {
            let content = response1.text();
            let res_json1;

            if (content.includes('"content"')) {
                res_json1 = JSON.parse(content);
            } else {
                let accesskey = response1.headers.accesskey;
                let keyString = response1.headers.keystring;
                if (accesskey && keyString) {
                    let res = decode(accesskey, keyString, content);
                    res_json1 = JSON.parse(res);
                } else {
                    res_json1 = JSON.parse(content);
                }
            }

            if (res_json1.message) {
                return Response.success(
                    "Đây là chương VIP. Nếu muốn đọc, bạn cần mua chương VIP ở Tấn Giang.<br>" +
                    "Nếu bạn đã mua, hãy tải lại chương này để cập nhật nội dung."
                );
            }

            let sayBody = res_json1.sayBody || "";
            let chap_content = res_json1.content || "";

            // Giải mã nội dung nếu cần
            if (chap_content && chap_content.length > 30) {
                chap_content = decryptContent(chap_content);
            }

            chap_content = formatContent(chap_content, sayBody);
            return Response.success(chap_content);
        } catch (e) {
            console.log("Lỗi xử lý VIP chapter: " + e.message);
            return Response.success("Lỗi khi xử lý chương VIP: " + e.message);
        }
    } else {
        // --- Chương free ---
        let response = fetch(url);
        if (!response.ok) return Response.success("Không thể tải nội dung chương.");

        try {
            let res_json = response.json();
            let sayBody = res_json.sayBody || "";
            let chap_content = res_json.content || "";

            return Response.success(formatContent(chap_content, sayBody));
        } catch (e) {
            console.log("Lỗi xử lý free chapter: " + e.message);
            return Response.success("Lỗi khi xử lý chương free: " + e.message);
        }
    }
}

// --- Hàm định dạng nội dung ---
function formatContent(chap_content, sayBody) {
    chap_content = (chap_content || "")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/\n　　/g, "<br>")
        .replace(/<br><br>/g, "<br>");

    if (sayBody.trim().length > 0) {
        chap_content += "<br>••••••••<br>作者留言：<br>" + sayBody.replace(/\r\n/g, "<br>");
    }
    return chap_content;
}