load('crypto.js');
load('decode.js');

function execute(url) {
    // Xác định xem có phải chương VIP không (giữ nguyên logic của bạn)
    let isVipChapter = url.includes("token") || url.includes("versionCode=349");

    // -----------------------------
    // LẤY TOKEN - RẤT CHẮC CHẮN
    // -----------------------------
    let token = null;
    try {
        // 1) từ settings (input)
        if (typeof settings !== 'undefined' && settings.JJWXC_TOKEN) {
            // Có thể settings.JJWXC_TOKEN là string hoặc object { value: "..." } tùy app
            let s = settings.JJWXC_TOKEN;
            if (typeof s === 'string') {
                token = s.trim();
                console.log("Token lấy từ settings (string), len=" + token.length);
            } else if (typeof s === 'object' && s !== null) {
                // thử các trường thường gặp
                if (typeof s.value === 'string' && s.value.trim().length > 0) {
                    token = s.value.trim();
                    console.log("Token lấy từ settings.value, len=" + token.length);
                } else if (typeof s[0] === 'string' && s[0].trim().length > 0) {
                    token = String(s[0]).trim();
                    console.log("Token lấy từ settings[0], len=" + token.length);
                } else {
                    // stringify fallback
                    try {
                        let maybe = JSON.stringify(s);
                        if (maybe && maybe.length > 0) {
                            token = maybe;
                            console.log("Token stringify từ settings object, len=" + token.length);
                        }
                    } catch(e){}
                }
            }
        }

        // 2) fallback sang biến toàn cục var JJWXC_TOKEN (mã bổ sung)
        if ((!token || token.length === 0) && typeof JJWXC_TOKEN !== 'undefined' && JJWXC_TOKEN) {
            token = String(JJWXC_TOKEN).trim();
            console.log("Token fallback từ var JJWXC_TOKEN, len=" + token.length);
        }
    } catch (e) {
        console.log("Lỗi khi lấy token: " + e.message);
        token = null;
    }

    // Nếu đã lấy token hợp lệ và URL chưa có token, gắn token vào url
    if (token && token.length > 0 && !url.includes("token=")) {
        if (url.includes("?")) {
            url += "&token=" + encodeURIComponent(token);
        } else {
            url += "?token=" + encodeURIComponent(token);
        }
    }

    // -----------------------------
    // XỬ LÝ CHƯƠNG VIP
    // -----------------------------
    if (isVipChapter) {
        // Kiểm tra token cơ bản
        if (!token || token.length < 10) {
            let html1 = `Token không hợp lệ hoặc chưa nhập.<br/>
                Vui lòng thêm token vào phần "Mã bổ sung" hoặc "Cài đặt":<br/>
                <code>var JJWXC_TOKEN = "token_của_bạn";</code><br/>
                Hoặc nhập token trong ô "Tấn Giang Token".`;
            return Response.success(html1);
        }

        let response1 = fetch(url);
        if (!response1.ok) {
            return Response.success("Không thể kết nối đến server VIP. Vui lòng thử lại.");
        }

        let content = response1.text();
        try {
            let res_json1 = null;

            // Nếu content có "content" trực tiếp thì parse ngay
            if (typeof content === 'string' && content.indexOf('"content"') !== -1) {
                res_json1 = JSON.parse(content);
            } else {
                // Nếu server trả header accesskey/keystring -> cần decode
                let accesskey = response1.headers && response1.headers.accesskey;
                let keyString = response1.headers && response1.headers.keystring;
                if (accesskey && keyString) {
                    try {
                        let decoded = decode(accesskey, keyString, content);
                        res_json1 = JSON.parse(decoded);
                    } catch (e) {
                        // fallback: thử parse thẳng
                        res_json1 = JSON.parse(content);
                    }
                } else {
                    // fallback: parse thẳng
                    res_json1 = JSON.parse(content);
                }
            }

            // Nếu server trả message -> báo VIP chưa mua / token không valid
            if (res_json1 && res_json1.message) {
                return Response.success(
                    "Đây là chương VIP. Nếu bạn đã mua chương, hãy reload/chờ đồng bộ nội dung; nếu chưa, hãy mua chương trong app."
                );
            }

            // Lấy nội dung
            let sayBody = (res_json1 && res_json1.sayBody) ? res_json1.sayBody : "";
            let chap_content = (res_json1 && res_json1.content) ? res_json1.content : "";

            // Giải mã nội dung nếu cần (dài và có vẻ mã hóa)
            if (chap_content && chap_content.length > 30) {
                try {
                    chap_content = decryptContent(chap_content);
                } catch (e) {
                    console.log("Không thể decrypt content (có thể không cần): " + e.message);
                }
            }

            // Xây dựng HTML nội dung trả về
            let html = buildContent(chap_content, sayBody);
            return Response.success(html);

        } catch (e) {
            console.log("Lỗi xử lý VIP chapter: " + e.message);
            return Response.success("Lỗi khi xử lý chương VIP: " + e.message);
        }
    }

    // -----------------------------
    // XỬ LÝ CHƯƠNG FREE
    // -----------------------------
    else {
        let response = fetch(url);
        if (!response.ok) {
            return Response.success("Không thể tải nội dung chương. Vui lòng thử lại.");
        }

        try {
            let res_json = response.json();
            let sayBody = (res_json && res_json.sayBody) ? res_json.sayBody : "";
            let chap_content = (res_json && res_json.content) ? res_json.content : "";
            return Response.success(buildContent(chap_content, sayBody));
        } catch (e) {
            console.log("Lỗi xử lý free chapter: " + e.message);
            return Response.success("Lỗi khi xử lý chương free: " + e.message);
        }
    }
}

// Hàm dựng nội dung
function buildContent(chap_content, sayBody) {
    chap_content = chap_content || "";
    sayBody = sayBody || "";

    try {
        chap_content = chap_content
            .replace(/&lt;/g, "<")
            .replace(/&gt;/g, ">")
            .replace(/\n　　/g, "<br>")
            .replace(/<br><br>/g, "<br>");
    } catch(e){}

    if (sayBody && String(sayBody).trim().length > 0) {
        chap_content += "<br>••••••••<br>作者留言：<br>" + String(sayBody).replace(/\r\n/g, "<br>");
    }
    return chap_content;
}