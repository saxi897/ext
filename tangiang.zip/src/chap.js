load('crypto.js');
load('decode.js');

function execute(url) {
    let isVipChapter = url.includes("vip") || url.includes("versionCode=349");
    let token = null;

    // --- Xử lý token từ mã bổ sung ---
    if (typeof JJWXC_TOKEN !== 'undefined' && JJWXC_TOKEN && JJWXC_TOKEN.trim().length > 0) {
        token = JJWXC_TOKEN.trim();
        if (!url.includes("token=")) {
            if (url.includes("?")) {
                url += "&token=" + encodeURIComponent(token);
            } else {
                url += "?token=" + encodeURIComponent(token);
            }
        }
    }

    // --- Xử lý chương VIP ---
    if (isVipChapter) {
        if (!token || token.length < 20) {
            let htmlError = `
                Token không hợp lệ hoặc chưa nhập.<br><br>
                 Vui lòng thêm token vào phần "Mã bổ sung":<br>
                <code>var JJWXC_TOKEN = "token_của_bạn";</code><br><br>
                Để lấy token, hãy đăng nhập app Tấn Giang và sao chép token người dùng.`;
            return Response.success(htmlError);
        }

        let response = fetch(url);
        if (response.ok) {
            let content = response.text();
            try {
                let json;

                if (content.includes('"content"')) {
                    json = JSON.parse(content);
                } else {
                    let accesskey = response.headers.accesskey;
                    let keyString = response.headers.keystring;
                    if (accesskey && keyString) {
                        let decrypted = decode(accesskey, keyString, content);
                        json = JSON.parse(decrypted);
                    } else {
                        json = JSON.parse(content);
                    }
                }

                if (json.message) {
                    return Response.success(
                        "Đây là chương VIP. Hãy đảm bảo bạn đã mua chương này trên app Tấn Giang.<br>Nếu đã mua, vui lòng tải lại chương."
                    );
                }

                let sayBody = json.sayBody || "";
                let chap_content = json.content || "";

                // Giải mã nếu nội dung bị mã hóa
                if (chap_content && chap_content.length > 30) {
                    chap_content = decryptContent(chap_content);
                }

                chap_content = buildContent(chap_content, sayBody);
                return Response.success(chap_content);

            } catch (e) {
                return Response.success("Lỗi xử lý chương VIP: " + e.message);
            }
        } else {
            return Response.success("Không thể kết nối đến server. Vui lòng thử lại.");
        }
    }

    // --- Xử lý chương miễn phí ---
    else {
        let response = fetch(url);
        if (response.ok) {
            try {
                let json = response.json();
                let sayBody = json.sayBody || "";
                let chap_content = json.content || "";
                return Response.success(buildContent(chap_content, sayBody));
            } catch (e) {
                return Response.success("Lỗi xử lý chương free: " + e.message);
            }
        } else {
            return Response.success("Không thể tải nội dung chương. Vui lòng thử lại.");
        }
    }
}

// --- Hàm hiển thị nội dung ---
function buildContent(chap_content, sayBody) {
    chap_content = chap_content || "";
    sayBody = sayBody || "";

    chap_content = chap_content
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/\n　　/g, "<br>")
        .replace(/<br><br>/g, "<br>");

    if (sayBody.trim().length > 0) {
        chap_content += "<br>••••••••<br>作者留言：<br>" + sayBody.replace(/\r\n/g, "<br>");
    }

    return chap_content;
}