load('crypto.js');
load('decode.js');

function execute(url) {
    // Xác định xem có phải chương VIP không
    let isVipChapter = url.includes("token") || url.includes("versionCode=349");

    // Lấy token: ưu tiên từ settings (input), sau đó đến var JJWXC_TOKEN
    let token = null;

    if (typeof settings !== 'undefined' && settings.JJWXC_TOKEN) {
        try { token = String(settings.JJWXC_TOKEN).trim(); } catch(e) { token = null; }
    }

    if ((!token || token.length === 0) && typeof JJWXC_TOKEN !== 'undefined' && JJWXC_TOKEN) {
        try { token = String(JJWXC_TOKEN).trim(); } catch(e) { token = null; }
    }

    // Nếu có token hợp lệ → thêm vào URL nếu chưa có
    if (token && token.length > 0 && !url.includes("token=")) {
        if (url.includes("?")) {
            url += "&token=" + encodeURIComponent(token);
        } else {
            url += "?token=" + encodeURIComponent(token);
        }
    }

    // Nếu là chương VIP
    if (isVipChapter) {
        let html1 = `Token không hợp lệ.<br/>
                     Vui lòng nhập token vào phần "Mã bổ sung" hoặc "Cài đặt" với cú pháp:<br/>
                     <code>var JJWXC_TOKEN = "token_của_bạn";</code><br/>
                     Hoặc nhập trực tiếp token trong mục "Tấn Giang Token".<br/>
                     Để lấy token, hãy đăng nhập app Tấn Giang và sao chép token.`;

        if (!token || token.length < 20) {
            return Response.success(html1);
        }

        let response1 = fetch(url);
        if (response1.ok) {
            let content = response1.text();
            let res_json1;

            try {
                if (content.includes('"content"')) {
                    res_json1 = JSON.parse(content);
                } else {
                    let accesskey = response1.headers.accesskey;
                    let keyString = response1.headers.keystring;
                    if (accesskey && keyString) {
                        let res = decode(accesskey, keyString, content);
                        res_json1 = JSON.parse(res);
                    } else {
                        res_json1 = JSON.parse(content);
                    }
                }

                if (res_json1.message) {
                    html1 = "Đây là chương VIP. Nếu muốn đọc bạn cần mua chương VIP ở Tấn Giang.<br>Reload lại sau khi mua hoặc liên hệ Góp ý nếu vẫn lỗi.";
                    return Response.success(html1);
                } else {
                    let sayBody = res_json1.sayBody || "";
                    let chap_content = res_json1.content || "";

                    // Giải mã nội dung khi cần
                    if (chap_content && chap_content.length > 30) {
                        chap_content = decryptContent(chap_content);
                    }

                    chap_content = getConent(chap_content, sayBody);
                    return Response.success(chap_content);
                }
            } catch (e) {
                console.log("Lỗi xử lý VIP chapter: " + e.message);
                return Response.success("Lỗi khi xử lý chương VIP: " + e.message);
            }
        } else {
            return Response.success("Không thể kết nối đến server. Vui lòng thử lại.");
        }
    }
    // Ngược lại: chương free
    else {
        console.log("Xử lý free chapter: " + url);
        let response = fetch(url);
        if (response.ok) {
            try {
                let res_json = response.json();
                let sayBody = res_json.sayBody || "";
                let chap_content = res_json.content || "";
                return Response.success(getConent(chap_content, sayBody));
            } catch (e) {
                console.log("Lỗi xử lý free chapter: " + e.message);
                return Response.success("Lỗi khi xử lý chương free: " + e.message);
            }
        } else {
            return Response.success("Không thể tải nội dung chương. Vui lòng thử lại.");
        }
    }
}

// Hàm xử lý nội dung chương
function getConent(chap_content, sayBody) {
    chap_content = chap_content || "";
    sayBody = sayBody || "";

    chap_content = chap_content
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/\n　　/g, "<br>")
        .replace(/<br><br>/g, "<br>");

    if (sayBody.trim().length > 0) {
        chap_content += "<br>••••••••<br>作者留言：<br>" + sayBody.replace(/\r\n/g, "<br>");
    }
    return chap_content;
}