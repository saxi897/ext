function execute() {
    return Response.success([
        {title: "VIP今日限免", input: "http://app-cdn.jjwxc.net/bookstore/vipNovelFreeByDate", script: "gen4.js"},
        {title: "新书榜单", input: "http://app.jjwxc.org/androidapi/newDayList", script: "gen2.js"},

    ]);
}