function execute(url, page) {
    if (!page) page = 1;
    let limit = 25;
    let offset = (page - 1) * limit;
    url = url.replace(/offset%22%3A%22\d+%22/g, "offset%22%3A%22" + offset + "%22%2C%22limit%22%3A%2225%22%7D%7D&channelMore=1");

    let response = fetch(url);

    if (response.ok) {
        let json = response.json();

        let list = (json.data && json.data.data) ? json.data.data : [];

        let data = [];

        for (let i = 0; i < list.length; i++) {
            data.push({
                name: list[i].novelName,
                detail: list[i].authorName,
                cover: "https://images.weserv.nl/?url=" + list[i].cover + "&output=jpg&w=300",
                link: "http://www.jjwxc.net/onebook.php?novelid=" + list[i].novelId,
                host: "http://www.jjwxc.net"
            });
        }

        return Response.success(data, (page + 1).toString());
    }

    return null;
}