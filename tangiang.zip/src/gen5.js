function execute(url, page) {
    if (!page) page = 1;
    const limit = 25;
    const offset = (page - 1) * limit;

    // Thay offset trực tiếp trong link (mã hóa sẵn)
    url = url.replace(/offset%22%3A%22\d+%22(%2C)?/, `offset%22%3A%22${offset}%22$1`);

    let data = [];

    let response = fetch(url);
    if (response.ok) {
        let json = response.json();

        // ✅ Lấy dữ liệu đúng chỗ: json.data.data
        let list = (json.data && Array.isArray(json.data.data)) ? json.data.data : [];

        for (let i = 0; i < list.length; i++) {
            let item = list[i];
            data.push({
                name: item.novelName,
                detail: item.authorName,
                cover: tem.cover,
                link: "http://www.jjwxc.net/onebook.php?novelid=" + item.novelId,
                host: "http://www.jjwxc.net"
            });
        }

        return Response.success(data, (page + 1).toString());
    }

    // ✅ Giữ nguyên logic code gốc: chỉ return null ở cuối
    return null;
}