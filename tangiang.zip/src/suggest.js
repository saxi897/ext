function execute(input) {
    let response = fetch(input);
    if (response.ok) {
        let doc = response.json();
        let books = [];

        let novelList = doc.novellist;
        if (novelList && typeof novelList === "object") {
            Object.keys(novelList).forEach(key => {
                let arr = novelList[key];
                if (Array.isArray(arr)) {
                    arr.forEach(item => {
                        books.push({
                            name: item.novelname,
                            link: "http://www.jjwxc.net/onebook.php?novelid=" + item.novelid,
                            cover: item.ebookurl,
                            author: item.authorname,
                            host: "http://www.jjwxc.net/",
                            description: item.tags
                        });
                    });
                }
            });
        }

        return Response.success(books);
    }

    return null;
}