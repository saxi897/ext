function execute(url) {
    let bookId = /-(\d+).html/.exec(url)[1];

    let response = fetch("https://webapi.gongzicp.com/novel/novelInfo?id=" + bookId);

    if (response.ok) {
        let data = response.json();
        if (data.code === 200) {
            let novelInfo = data.data;
            let ongoing = (novelInfo.novel_process_index === 1);
            return Response.success({
                name: novelInfo.novel_name,
                cover: novelInfo.novel_cover,
                author: novelInfo.author_nickname,
                description: novelInfo.novel_info,
                detail: novelInfo.novel_name + "<br>◎作者： " + novelInfo.author_nickname + "<br>◎" + novelInfo.novel_tag_txt + "<br>◎" + novelInfo.type_names + " / " + novelInfo.novel_process + " / " + novelInfo.novel_wordnumber + "<br>◎" + novelInfo.novel_newcname,
                ongoing: ongoing,
                url: "https://www.gongzicp.com/novel-" + bookId + ".html"
            });
        }
    }

    return null;
}