function execute(url, page) {
    if (!page) page = '1';
    let lurl = url.replace("{{page}}", page);
    let next = (parseInt(page) + 1);

    let response = fetch(lurl);
    if (response.ok) {
        let data = response.json();
        if (data.code === 200) {

            let bookList = [];
            data.data.list.forEach(novel => {
                bookList.push({
                    name: novel.novel_name,
                    link: "https://www.gongzicp.com/novel-" + novel.novel_id + ".html",
                    cover: novel.novel_cover,
                    description: novel.novel_author
                });
            });

            return Response.success(bookList, next);
        }
    }

    return null;
}