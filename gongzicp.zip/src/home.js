function execute() {
    return Response.success([
        {title: "全部（分类）", input: "https://webapi.gongzicp.com/novel/novelGetList?page={{page}}&size=10&tid=17&field=0&order=-1", script: "gen.js"},
        {title: "上架榜", input: "https://webapi.gongzicp.com/novel/rankingGetList?tid=17&rid=3&date=2&page={{page}}", script: "gen2.js"},
        {title: "热度榜", input: "https://webapi.gongzicp.com/novel/rankingGetList?tid=17&rid=10&date=1&page={{page}}", script: "gen2.js"},
        {title: "收藏榜", input: "https://webapi.gongzicp.com/novel/rankingGetList?tid=17&rid=9&date=1&page={{page}}", script: "gen2.js"},
        {title: "推荐榜", input: "https://webapi.gongzicp.com/novel/rankingGetList?tid=17&rid=8&date=1&page={{page}}", script: "gen2.js"},
        
    ]);
}
